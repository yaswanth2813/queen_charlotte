import React from 'react';
import { Breadcrumbs as MUIBreadcrumbs, Link, Typography} from '@material-ui/core';
import { useLocation,
    useNavigate,
    useParams } from "react-router-dom";



const Breadcrumbs = (props) => {

    const location = useLocation();
    const navigate = useNavigate();
    const match = useParams();

    const { pathname } = location;
    const pathnames = pathname.split("/").filter(x => x);
    
    console.log("BreadCrumb props location: ", pathnames)
    console.log("BreadCrumb props location: ", location)
    console.log("BreadCrumb props navigate: ", navigate)
    console.log("BreadCrumb props match: ", match)



  return (
    <MUIBreadcrumbs aria-label="breadcrumb">
      { 
      pathnames.map((name, index) => {
          const routeTo = `/${pathnames.slice(0, index+1).join("/")}`;
        return <Link onClick={() => navigate(routeTo) }> {name}</Link> 
      })
      }
    </MUIBreadcrumbs>
  );
};

export default Breadcrumbs;
